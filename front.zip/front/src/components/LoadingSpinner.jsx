export const LoadingSpinner = () => {
    return(
        <div className="spinner-conteiner">
            <div className="spinner"/>
        </div>
    )
}