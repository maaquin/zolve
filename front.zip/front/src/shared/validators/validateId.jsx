export const validateId = (id) => {
    return true
}

export const validateIdMessage = 'Holanda, my first easter egg'